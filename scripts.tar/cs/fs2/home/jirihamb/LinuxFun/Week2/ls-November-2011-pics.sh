#! /bin/bash

./ls-November-2011.sh | grep '.*\.jpg'
