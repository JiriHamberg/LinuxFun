#! /bin/bash

echo "$*"
