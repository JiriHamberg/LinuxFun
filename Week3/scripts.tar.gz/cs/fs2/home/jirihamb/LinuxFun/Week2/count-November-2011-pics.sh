#! /bin/bash

./ls-November-2011-pics.sh | wc -l
